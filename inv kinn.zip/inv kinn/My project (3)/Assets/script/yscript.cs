using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class yscript : MonoBehaviour
{
    [SerializeField] private Slider _slider;
    public float yaxes;
    private string yaxess;
    [SerializeField] private TextMeshProUGUI _sliderText;

    void Start()
    {
        _slider.onValueChanged.AddListener((v) =>
        {
            _sliderText.text = v.ToString("0.00");
            yaxess = v.ToString("0.00");
            float.TryParse(yaxess, out yaxes);
        });
    }
}

