using UnityEngine;

public class zrotation : MonoBehaviour
{
    public GameObject uiGameObject; // Reference to the GameObject with the ui script
    private zscript zscript; // Corrected variable name and data type

    public GameObject joint0; // Reference to the joint0 game object
    float z = 0;

    void Start()
    {
        // Get the uiScript component from the uiGameObject
        zscript = uiGameObject.GetComponent<zscript>();


    }

    // Update is called once per frame
    void Update()
    {
        // Access the public float variable xaxes from the uiScript
        z = zscript.zaxes;
        Debug.Log(z);


        // Set the rotation of the joint0 object based on the x value
        Quaternion newRotation = Quaternion.Euler(z, 90f, 90f);
        joint0.transform.rotation = newRotation;
    }
}

