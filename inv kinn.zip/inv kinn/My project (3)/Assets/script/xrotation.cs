using UnityEngine;

public class xrotation : MonoBehaviour
{
    public GameObject uiGameObject; // Reference to the GameObject with the ui script
    public Transform GameObject;
    private  xscript xscript; // Corrected variable name and data type
    public GameObject joint0; // Reference to the joint0 game object
    float x = 0;
   
   

    void Start()
    {
        // Get the uiScript component from the uiGameObject
        xscript = uiGameObject.GetComponent<xscript>();
        
    }

    // Update is called once per frame
    void Update()
    {
        // Access the public float variable xaxes from the uiScript
         x = xscript.xaxes;
        // Get the rotation of the game object
       
        // Convert the rotation to Euler angles
     

      
        

        // Set the rotation of the joint0 object based on the x value
        Quaternion newRotation = Quaternion.Euler(0f, x, 0f);
        joint0.transform.rotation = newRotation;
    }
}

