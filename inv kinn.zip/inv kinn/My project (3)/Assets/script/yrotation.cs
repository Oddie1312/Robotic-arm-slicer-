using UnityEngine;

public class yrotation : MonoBehaviour
{
    public GameObject uiGameObject; // Reference to the GameObject with the ui script
    private yscript yscript; // Corrected variable name and data type
 
    public GameObject joint0; // Reference to the joint0 game object
    float y = 0;
 
    void Start()
    {
        // Get the uiScript component from the uiGameObject
        yscript = uiGameObject.GetComponent<yscript>();


    }

    // Update is called once per frame
    void Update()
    {
        // Access the public float variable xaxes from the uiScript
        y = yscript.yaxes;
       
     

        // Set the rotation of the joint0 object based on the x value
        Quaternion newRotation = Quaternion.Euler(0f, y, 0f);
        joint0.transform.rotation = newRotation;
    }
}

