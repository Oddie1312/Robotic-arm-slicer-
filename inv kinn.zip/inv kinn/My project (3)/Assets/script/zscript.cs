using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class zscript : MonoBehaviour
{
    [SerializeField] private Slider _slider;
    public float zaxes;
    private string zaxess;
    [SerializeField] private TextMeshProUGUI _sliderText;

    void Start()
    {
        _slider.onValueChanged.AddListener((v) =>
        {
            _sliderText.text = v.ToString("0.00");
            zaxess = v.ToString("0.00");
            float.TryParse(zaxess, out zaxes);
        });
    }
}

