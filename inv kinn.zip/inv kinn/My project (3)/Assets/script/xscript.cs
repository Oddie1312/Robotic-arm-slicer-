using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class xscript : MonoBehaviour
{
    [SerializeField] private Slider _slider;
    public float xaxes;
    private string xaxess;
    [SerializeField] private TextMeshProUGUI _sliderText;

    void Start()
    {
        _slider.onValueChanged.AddListener((v) =>
        {
            _sliderText.text = v.ToString("0.00");
            xaxess = v.ToString("0.00");
            float.TryParse(xaxess, out xaxes);
        });
    }
}

